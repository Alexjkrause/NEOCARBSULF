 function run = Neocarbsulf_frontend_MC(s,mc_params)

%%% This work is a revision of Bob Berner's Geocarbsulfvolc (GCBSv) model (2006-2009)
%%% By Alex Krause (2018)
%%% This includes the Godderis et al. (2012) and Royer et al. (2014)
%%% updates to the dimensionless parameters and CO2 climate sensitivity which
%%% can be turned on or off (i.e. back to Berner's 2009 values), and new d13C
%%% isotope and d34S isotope data.


% Globals

global pars
global forcings
global cisotopes
global royervolc
global gcm
global dynamic_ancients
global stepnumber
global workingstate
global timer

%%% load in spreadsheets

forcings.land_data = xlsread('New_Forcings/arrays.xlsx','','','basic'); % loads dimensionless parameters
% forcings.strontium = xlsread('New_Forcings/strontium.xlsx','','','basic'); % loads in new strontium isotope data
forcings.crustal = xlsread('New_Forcings/crustal_carbon.xlsx','','','basic'); % loads in total carbon in the crust
forcings.new_fA = xlsread('New_Forcings/Hawkes_fA.xlsx','','','basic'); % loads in new land area data from Hawkesworth et al 2016
forcings.new_GEOG = xlsread('New_Forcings/GEOG.xlsx','','','basic'); % loads in new palaegeography effect on temp from Godderis et al 2017



%%% turn on/off updates to the original Geocarbsulfvolc model

% royervolc = 'off'; % uses the Royer et al. values for certain volc-related parameters
% gcm = 'off'; % uses Royer et al. values for calculating the gamma aspect of CO2 dependent, climate sensitivity in weathering equations
% dynamic_ancients = 'on'; % allows the young to ancient reservoir flux to be dependent on the size of the young reservoir, allowing ancient reservoir sizes to vary


%%% Present Day Values

pars.A0 = 3.193e18; % CO2 in atmosphere and ocean at present
pars.O0 = 3.8e19; % O2 in atmosphere at present
pars.temp_0 = 288; % 15 deg C expressed in Kelvin
pars.Pyr_0 = 12.8571e18; % Present day size of young pyrite reservoir based on Berner's assumption that young pyrite is 1/14th the size of total pyrite, and the COPSE value of 180e18 for total pyrite;
pars.Gyp_0 = 100e18; % Present day size of young gypsum reservoir - COPSE value is 200e18 and is split equally between young and ancient reservoirs;
pars.OA_S_0 = 38e18; % Present day ocean-atmosphere sulphate reservoir


%%% Initial values of reservoirs, used to kick start the model

pars.OA_S = 38e18; % Ocean-atmosphere sulphur
pars.OA_C = 31e18; % Ocean-atmosphere carbon - allows the reservoir to reach near present level (in moles) at the end of model run, but the value itself has no effect on RCO2 levels

% pars.G_y = 330.625e18; % Young organic carbon reservoir - prev. value: 250e18
% pars.G_a = 1106.875e18; % Ancient organic carbon reservoir - prev. value: 1000e18
% pars.C_y = 1106.875e18; % Young carbonate reservoir - prev. value: 1000e18
% pars.C_a = 3705.625e18; % Ancient carbonate reservoir - prev. value: 4000e18

% pars.G_y = 302.5e18; % Young organic carbon reservoir - prev. value: 250e18
% pars.G_a = 1072.5e18; % Ancient organic carbon reservoir - prev. value: 1000e18
% pars.C_y = 1072.5e18; % Young carbonate reservoir - prev. value: 1000e18
% pars.C_a = 3802.5e18; % Ancient carbonate reservoir - prev. value: 4000e18

% pars.G_y = 360e18; % Young organic carbon reservoir - prev. value: 250e18
% pars.G_a = 1140e18; % Ancient organic carbon reservoir - prev. value: 1000e18
% pars.C_y = 1140e18; % Young carbonate reservoir - prev. value: 1000e18
% pars.C_a = 3610e18; % Ancient carbonate reservoir - prev. value: 4000e18

pars.G_y = 225.625e18; % Young organic carbon reservoir - prev. value: 250e18
pars.G_a = 961.875e18; % Ancient organic carbon reservoir - prev. value: 1000e18
pars.C_y = 961.875e18; % Young carbonate reservoir - prev. value: 1000e18
pars.C_a = 4100.625e18; % Ancient carbonate reservoir - prev. value: 4000e18


% The following are the new sizes of sulphur reservoirs, with gypsum equal to ~25% of total sulphur minus ocean-atmosphere sulphate.
% The total sulphur has been reduced from 638e18 to 418e18 so that the model runs in steady
% state and ends with reservoirs achieving their modern day values

pars.Pyr_y = 20e18; % Young pyrite reservoir
pars.Pyr_a = 260e18; % Ancient pyrite reservoir
pars.Gyp_y = 50e18; % Young gypsum reservoir
pars.Gyp_a = 50e18; % Ancient gypsum reservoir


%%% Rate constants for young reservoirs - the constants in the sulphur equations 
%%% are larger than other rate constants as in these equations we're 
%%% multiplying by smaller amounts, due to normalisation of reservoirs

pars.k_wg = 0.02; %0.013; %0.018; % organic carbon weathering
pars.k_wc = 0.02; %0.013; %0.018; % carbonate weathering
pars.k_wp = 4.55e17; % 4.6e17; % young pyrite weathering
pars.k_wgyp = 0.625e18; %1.2e18; % young gypsum weathering

% Rate constants for old reservoirs

pars.kwgypa = 0.0026; %0.0024; %0.0026; %0.0033; % gypsum weathering
pars.kmgypa = 0.0026; %0.0024; %0.0026; %0.0033; % gypsum degassing
pars.kwpa = 0.000895; %0.000897; % pyrite weathering - prev. value: 0.000893
pars.kmpa = 0.000895; %0.000897; % pyrite degassing - prev. value: 0.000893
pars.kwca = 0.00056; %0.0005; % carbonate weathering
pars.kmca = 0.00129; %0.00135; %0.00125; %0.001655; % carbonate degassing - prev value: 0.001668
pars.kwga = 0.00056; %0.0005; % organic carbon weathering
pars.kmga = 0.00129; %0.00135; %0.00125; % organic carbon degassing

%%% Rate constants for the burial equations for the sulphur cycle -
%%% reservoirs are normalised hence large rate constants

pars.k_bp = 1.45e18; %1.35e18; %1.3e18; % pyrite burial 1.55e18;
pars.k_bgyp = 2.1e18; %1.9e18; %2.6e18; % gypsum burial - prev. value: 1.6e18   3.25e18;

%%% Rate constants which allow the young-ancient flux to vary as a function
%%% of young reservoir size, instead of equalling the combined weathering
%%% plus degassing fluxes of ancient reservoirs

pars.k_p_ya = 0.01; % young-ancient flux for pyrite
pars.k_gyp_ya = 0.01; % young-ancient flux for gypsum
pars.k_g_ya = 0.018; % young-ancient flux for organic carbon
pars.k_c_ya = 0.018; % young-ancient flux for carbonate


%%% Constant parameters

pars.ACT_si = 0.09; % Activation energy for silicates
pars.ACT_carb = 0.087; % Activation energy for carbonates
pars.Ws = 20.58; %12.9; %7.4; % Effect of solar insolation on global avg temp
pars.FERT = 0.4; % Proportion of plants that are fertilised by increasing CO2 and affect weathering
pars.albedo_0 = 0.3; %0.2992; % Roughly current day albedo value
pars.n = 1; %1.5; % Empirical parameter for d34S fractionation
pars.Rv = 0.704; % Avg value of 87Sr/86Sr of sub-aerial and submarine volcanic rocks
pars.Xvolc_0 = 0.35; % Fraction of total Ca and Mg silicate weathering derived from volcanic rocks at present


% %% Varying various volcanic rock related parameters/fluxes
% if strcmp(royervolc, 'on')
% Royer values
% pars.VNV = 5; % rate ratio of chemical weathering in volcanic to non-volcanic silicate rocks (called "Wv/Wnv in Berner 2006b)
% pars.NV = 0.0075; % arbitrary parameter varying from 0 to 0.015
% pars.F_bo_0 = 4e18; % rate of exchange of Ca and Mg between basalt and seawater at present
% elseif strcmp(royervolc, 'off')
    pars.VNV = 2; % Berner's standard run rate ratio
    pars.NV = 0.015; % Berner's standard run parameter
    pars.F_bo_0 = 5e18; % Berner's rate of exchange
% end


%%% Present day flux values

pars.F_ws_0 = 6.67e18; % Present Si weathering rate
pars.F_wp_a0 = 0.25e18; % Weathering of ancient pyrite
pars.F_wgyp_a0 = 0.5e18; % Weathering of ancient gypsum
pars.F_wg_a0 = 0.5e18; % Weathering of ancient organic carbon
pars.F_wc_a0 = 2e18; % Weathering of ancient carbonate
pars.F_mp_0 = 0.25e18; % Degassing of ancient pyrite
pars.F_ms_0 = 0.5e18; % Degassing of ancient gypsum
pars.Fmg_0 = 1.25e18; % Degassing of ancient organic carbon
pars.Fmc_0 = 6.67e18; % Degassing of ancient carbonates
pars.F_bg_0 = 5e18; % Burial of organic carbon (COPSE model has between 4.5 - 5.5)
pars.F_wc_y0 = 11.35e18; % Weathering of young carbonate (COPSE model has 13.35e18 for total F_wc)


%%% Initial parameters

pars.CO2_SAL = 20; % Rough value at start of Phanerozoic for Geocarbsulf volc
pars.O2_SAL =  0.01; %0.1; %0.15; %0.3; %0.27; %0.198; % 0.6579; % O2_start compared to PAL - lower levels not used here are for other runs, we start with PAL in the revised model to allow for model spin-up


%%% Reservoir starting sizes - to feed into ODE solver

pars.OA_S_start = pars.OA_S;
pars.OA_C_start = pars.OA_C;
pars.Pyr_y_start = pars.Pyr_y;
pars.Pyr_a_start = pars.Pyr_a;
pars.Gyp_y_start = pars.Gyp_y;
pars.Gyp_a_start = pars.Gyp_a;
pars.G_y_start = pars.G_y;
pars.G_a_start = pars.G_a;
pars.C_y_start = pars.C_y;
pars.C_a_start = pars.C_a;

pars.CO2_start = 6.3860e19; % SAL of 11 = 3.193e18 * 11 >> see what SAL is above
pars.O2_start = 3.8e17; %3.8e18; %1.14e19; %1.026e19; %3.8e19; %7.524e18; % 2.5e19; % Starting atmospheric O2 levels for 570 Ma, 3.8e19 is 1 PAL


%%% Isotope starting values for reservoirs

pars.delta_in = -5 ; % average isotopic composition of crustal carbon
pars.St = pars.Pyr_y_start + pars.Pyr_a_start + pars.Gyp_y_start + pars.Gyp_a_start + pars.OA_S_start; % Total sulphur in the system
% pars.Ct = pars.G_y_start + pars.G_a_start + pars.C_y_start + pars.C_a_start + pars.OA_C_start; % Total carbon in the system
pars.dlst = 4; % Starting isotope value for total sulphur
% pars.dlct = -3; %-5.5; % Starting isotope value for total carbon

pars.delta_OA_S_start = 23; % Ocean-atmosphere sulphur isotope value at 570 Ma - 23 for Wu et al., 35.2 for Berner
pars.delta_OA_C_start = -0.55; %5.39; %3.579437; % Ocean-atm carbon at 570 Ma - this is for the Saltzman and Thomas average, use 0 for Berner
pars.delta_p_y_start = 1; % young pyrite
pars.delta_p_a_start = 1; % old pyrite
pars.delta_gyp_y_start = 35; % young gypsum
pars.delta_gyp_a_start = (pars.dlst .* pars.St - (pars.delta_p_y_start .* pars.Pyr_y_start + pars.delta_gyp_y_start .* pars.Gyp_y_start + pars.delta_p_a_start .* pars.Pyr_a_start)) ./ pars.Gyp_a_start; % Calculated ancient gypsum
pars.delta_g_y_start = -27; % young organic carbon
pars.delta_g_a_start = -27; % old organic carbon
pars.delta_c_y_start = 0; % young carbonate
pars.delta_c_a_start = 0 ; % ancient carbonate - prev: = (pars.dlct * pars.Ct - (pars.delta_g_y_start * pars.G_y_start + pars.delta_c_y_start * pars.C_y_start + pars.delta_g_a_start * pars.G_a_start)) / pars.C_a_start;

%%% Starting values for Sr isotopes of carbonates

% pars.R_cy_start = 0.7095; % Average value of 87Sr/86Sr for young carbonates undergoing weathering
% pars.R_ca_start = 0.709; % Average value of 87Sr/86Sr for ancient carbonates undergoing weathering


%%%%%%%%%%%%%%%%%% MONTE CARLO %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

forcings.new_degas = xlsread('New_Forcings/Meso-Present_degassing.xlsx','','','basic'); % loads in new degassing data
forcings.new_fR = xlsread('New_Forcings/Hay_smooth.xlsx','','','basic'); % loads in new f_R data taken from Hay et al. (2006)
forcings.d13C = xlsread('New_Forcings/d13C_10myr.xlsx','','','basic'); % loads in d13C data - Havig et al 2015 from 1600 - 918 and Saltzman and Thomas 915 to Present
forcings.alphaC = xlsread('New_Forcings/Upper_lower_alphaC_JKT.xlsx','','','basic'); % loads in upper and lower bounds of d13C fractionation from Krissansen-Totton et al (2015)
% load OA_C % loads in d13C isotope data as a mat file instead of spreadsheet

if isfield(mc_params,'degas_mc') == 1
    f_G_min = forcings.new_degas(:,2); % Extract Min Degas
    f_G_max = forcings.new_degas(:,3); % Extract Max 
    f_G_time = forcings.new_degas(:,1); % Extract Time

    forcings.new_f_G = ones(length(f_G_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_f_G(:,1) = f_G_time;
    for ni = 1:length(f_G_min)
        forcings.new_f_G(ni,2) = f_G_min(ni) + (f_G_max(ni) - f_G_min(ni)) .* rand;
    end
end


if isfield(mc_params,'uplift_mc') == 1
    f_R_min = forcings.new_fR(:,4); % Extract Min uplift
    f_R_max = forcings.new_fR(:,2); % Extract Max 
    f_R_time = forcings.new_fR(:,1); % Extract Time

    forcings.new_f_R = ones(length(f_R_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_f_R(:,1) = f_R_time;
    for ni = 1:length(f_R_min)
        forcings.new_f_R(ni,2) = f_R_min(ni) + (f_R_max(ni) - f_R_min(ni)) .* rand;
    end
end

if isfield(mc_params,'c_isotopes_mc') == 1
    delta_OA_C_min = forcings.d13C(:,4); % Extract minus 1SD C isotopes
    delta_OA_C_max = forcings.d13C(:,3); % Extract plus 1SD
    delta_OA_C_time = forcings.d13C(:,1); % Extract Time

%     delta_OA_C_min = cisotopes.sd_min(:,1); % Extract minus 1SD C isotopes
%     delta_OA_C_max = cisotopes.sd_plus(:,1); % Extract plus 1SD
%     delta_OA_C_time = cisotopes.OAC_time(:,1); % Extract Time

    cisotopes.new_delta_OA_C = ones(length(delta_OA_C_time),2); % Create matrix of same size as input forcing to create random forcing
    cisotopes.new_delta_OA_C(:,1) = delta_OA_C_time;
    for ni = 1:length(delta_OA_C_min)
        cisotopes.new_delta_OA_C(ni,2) = delta_OA_C_min(ni) + (delta_OA_C_max(ni) - delta_OA_C_min(ni)) .* rand;
    end
end


if isfield(mc_params,'JKT_alpha_mc') == 1
    new_alpha_min = forcings.alphaC(:,2); % Extract Min JKT alpha C
    new_alpha_max = forcings.alphaC(:,3); % Extract Max 
    new_alpha_time = forcings.alphaC(:,1); % Extract Time

    forcings.new_alpha = ones(length(new_alpha_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_alpha(:,1) = new_alpha_time;
    for ni = 1:length(new_alpha_min)
        forcings.new_alpha(ni,2) = new_alpha_min(ni) + (new_alpha_max(ni) - new_alpha_min(ni)) .* rand;
    end
end


if isfield(mc_params,'gscaling_mc') == 1
    gscale_min = 4;
    gscale_max = 10;
  forcings.gscale = gscale_min + (gscale_max - gscale_min) .* rand;   
end   
    
if isfield(mc_params,'pscaling_mc') == 1
    pscale_min = 4;
    pscale_max = 10;
    forcings.pscale = pscale_min + (pscale_max - pscale_min) .* rand;     
end

if isfield(mc_params,'evapscaling_mc') == 1
    evapscale_min = 4;
    evapscale_max = 10;
    forcings.evapscale = evapscale_min + (evapscale_max - evapscale_min) .* rand;     
end

if isfield(mc_params,'runoff_mc') == 1
    f_D_min = forcings.land_data(:,4) - 0.5; % Extract Min uplift
    f_D_max = forcings.land_data(:,4) + 0.5; % Extract Max 
    f_D_time = forcings.land_data(:,1); % Extract Time

    forcings.new_f_D = ones(length(f_D_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_f_D(:,1) = f_D_time;
    for ni = 1:length(f_D_min)
        forcings.new_f_D(ni,2) = f_D_min(ni) + (f_D_max(ni) - f_D_min(ni)) .* rand;
    end
end

if isfield(mc_params,'faw_mc') == 1
    f_AW_min = forcings.land_data(:,3) - 0.5; % Extract Min uplift
    f_AW_max = forcings.land_data(:,3) + 0.5; % Extract Max 
    f_AW_time = forcings.land_data(:,1); % Extract Time

    forcings.new_f_AW = ones(length(f_AW_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_f_AW(:,1) = f_AW_time;
    for ni = 1:length(f_AW_min)
        forcings.new_f_AW(ni,2) = f_AW_min(ni) + (f_AW_max(ni) - f_AW_min(ni)) .* rand;
    end
end

if isfield(mc_params,'carb_area_mc') == 1
    f_L_min = forcings.land_data(:,5) - 0.5; % Extract Min uplift
    f_L_max = forcings.land_data(:,5) + 0.5; % Extract Max 
    f_L_time = forcings.land_data(:,1); % Extract Time

    forcings.new_f_L = ones(length(f_L_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_f_L(:,1) = f_L_time;
    for ni = 1:length(f_L_min)
        forcings.new_f_L(ni,2) = f_L_min(ni) + (f_L_max(ni) - f_L_min(ni)) .* rand;
    end
end

if isfield(mc_params,'land_area_mc') == 1
    f_A_min = forcings.new_fA(:,2) - 0.25; % Extract Min
    f_A_max = forcings.new_fA(:,2) + 0.25; % Extract Max 
    f_A_time = forcings.new_fA(:,1); % Extract Time

    forcings.new_f_A = ones(length(f_A_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_f_A(:,1) = f_A_time;
    for ni = 1:length(f_A_min)
        forcings.new_f_A(ni,2) = f_A_min(ni) + (f_A_max(ni) - f_A_min(ni)) .* rand;
    end
end

if isfield(mc_params,'geog_mc') == 1
    geog_min = forcings.new_GEOG(:,2) - 4; % Extract Min
    geog_max = forcings.new_GEOG(:,2) + 4; % Extract Max 
    geog_time = forcings.new_GEOG(:,1); % Extract Time

    forcings.new_geog = ones(length(geog_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_geog(:,1) = geog_time;
    for ni = 1:length(geog_min)
        forcings.new_geog(ni,2) = geog_min(ni) + (geog_max(ni) - geog_min(ni)) .* rand;
    end
end

% if isfield(mc_params,'geog_mc') == 1
%     geog_min = forcings.new_GEOG(:,3) - 9; % Extract Min
%     geog_max = forcings.new_GEOG(:,3) + 7; % Extract Max 
%     geog_time = forcings.new_GEOG(:,1); % Extract Time
% 
%     forcings.new_geog = ones(length(geog_time),2); % Create matrix of same size as input forcing to create random forcing
%     forcings.new_geog(:,1) = geog_time;
%     for ni = 1:length(geog_min)
%         forcings.new_geog(ni,2) = geog_min(ni) + (geog_max(ni) - geog_min(ni)) .* rand;
%     end
% end


if isfield(mc_params,'org_dep_mc') == 1
    org_dep_min = 0;
    org_dep_max = 1;
    forcings.org_dep = org_dep_min + (org_dep_max - org_dep_min) .* rand;     
end

% Curve fitting parameter representing strength of effect of O2 on d13C fractionation
if isfield(mc_params,'J_mc') == 1
    J_min = 0.1;
    J_max = 7;
    forcings.J = J_min + (J_max - J_min) .* rand;
end


if isfield(mc_params,'alpha_0_mc') == 1
    alpha_0_min = 24;
    alpha_0_max = 30;
    forcings.alpha_0 = alpha_0_min + (alpha_0_max - alpha_0_min) .* rand;
end


if isfield(mc_params,'crustal_mc') == 1
    crustal_min = forcings.crustal(:,4); % Extract Min crustal carbon
    crustal_max = forcings.crustal(:,3); % Extract Max 
    crustal_time = forcings.crustal(:,1); % Extract Time

    forcings.new_crustal = ones(length(crustal_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_crustal(:,1) = crustal_time;
    for ni = 1:length(crustal_min)
        forcings.new_crustal(ni,2) = crustal_min(ni) + (crustal_max(ni) - crustal_min(ni)) .* rand;
    end
end


if isfield(mc_params,'gamma_mc') == 1
    gamma_min = -1;
    gamma_max = 1;
    forcings.gamma = gamma_min + (gamma_max - gamma_min) .* rand;
end


if isfield(mc_params,'clim_run_mc') == 1
    clim_run_min = 0.025;
    clim_run_max = 0.065;
    forcings.clim_run = clim_run_min + (clim_run_max - clim_run_min) .* rand;
end


if isfield(mc_params,'plants_mc') == 1
    plants_min = 0.1;
    plants_max = 0.25;
    forcings.pre_plant = plants_min + (plants_max - plants_min) .* rand;
end


% if isfield(mc_params,'sulph_frac_mc') == 1
%     s_frac_min = 16.7;
%     s_frac_max = 48.1;
%     forcings.sulph_frac = s_frac_min + (s_frac_max - s_frac_min) .* rand;
% end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% set stepnumber to 1
stepnumber = 1 ;


%%% starting states

pars.startstate(1) = pars.OA_S_start;
pars.startstate(2) = pars.OA_C_start;
pars.startstate(3) = pars.Pyr_y_start;
pars.startstate(4) = pars.Pyr_a_start;
pars.startstate(5) = pars.Gyp_y_start;
pars.startstate(6) = pars.Gyp_a_start;
pars.startstate(7) = pars.G_y_start;
pars.startstate(8) = pars.G_a_start;
pars.startstate(9) = pars.C_y_start;
pars.startstate(10) = pars.C_a_start;
pars.startstate(11) = pars.delta_p_y_start .* pars.Pyr_y_start;
pars.startstate(12) = pars.delta_p_a_start .* pars.Pyr_a_start;
pars.startstate(13) = pars.delta_gyp_y_start .* pars.Gyp_y_start;
pars.startstate(14) = pars.delta_gyp_a_start .* pars.Gyp_a_start;
pars.startstate(15) = pars.delta_g_y_start .* pars.G_y_start;
pars.startstate(16) = pars.delta_g_a_start .* pars.G_a_start;
pars.startstate(17) = pars.delta_c_y_start .* pars.C_y_start;
pars.startstate(18) = pars.delta_c_a_start .* pars.C_a_start;
pars.startstate(19) = pars.O2_start;
pars.startstate(20) = pars.CO2_start;
pars.startstate(21) = 283; %295; % temperature start
pars.startstate(22) = 6.7e18; % F_ws start
pars.startstate(23) = 7.6e20;

%%% model timeframe - moves from 570 Ma to present (0)

pars.whenstart = -1600;
pars.whenend = 0;

%%%% show time in command window

% timer = 1;

%%%% note model start time
tic

%%% model run - feeds all information into ODE solver, runs for a max time
%%% step of 10 million years

options = odeset('maxstep', 10);

[rawoutput.T,rawoutput.Y] = ode15s(@Neocarbsulf_MC, [pars.whenstart pars.whenend], pars.startstate, options, mc_params);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Postprocessing   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% takes 'workingstate' from model and turns into 'state' %%%%%%%

%%% size of output 
pars.output_length = length(rawoutput.T) ;
%%%%%%%%%% model finished output to screen
fprintf('Integration finished \t') ; fprintf('Total steps: %d \t' , stepnumber ) ; fprintf('Output steps: %d \n' , pars.output_length ) 
toc

%%%%%%%%% print final model states using final state for each timepoint
%%%%%%%%% during integration
fprintf('assembling state vectors... \t')
tic

%%%% trecords is index of shared values between ode15s output T vector and
%%%% model recorded workingstate t vector
[sharedvals,trecords] = intersect(workingstate.time,rawoutput.T,'stable') ;

%%%%%% assemble output state vectors
field_names = fieldnames(workingstate) ;
for numfields = 1:length(field_names)
    eval([' state.' char( field_names(numfields) ) ' = workingstate.' char( field_names(numfields) ) '(trecords) ; '])
end

timegrid = -1600:1:0;
timegrid = timegrid';

state_fields = fieldnames(state);
% Interpolate model outputs to set time grid
for i=1:length(state_fields)
        varName(i) = matlab.lang.makeValidName(string(strcat(state_fields(i),"_gridded")));
        inter_state.(varName(i)) = interp1(state.time,state.(string(state_fields(i))),timegrid);
        inter_state.(varName(i))(1:100) = [];
        clear varName
end

% Add state vectors to individual run structure

run.state = inter_state;


%%%%%% done message
fprintf('Done: ')
endtime = toc ;
fprintf('time (s): %d \n', endtime )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Cleanup workspace   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear state
clear stepnumber
clear u
clear numfields
clear trecords
clear finalrecord
clear field_names
clear n
clear veclength
clear xvec
clear yvec
clear endtime
clear workingstate
clear state
clear inter_state
clear t


end
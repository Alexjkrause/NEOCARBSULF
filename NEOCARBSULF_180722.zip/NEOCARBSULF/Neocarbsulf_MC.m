function dy = Neocarbsulf_MC(t,y,mc_params)

%%% Equations underpinning the revision of Bob Berner's Geocarbsulfvolc (GCBSv) model (2006-2009)
%%% amended to be GEOCARBSULFOR (Krause et al., 2018) and then updated
%%% further to run through the Neoproterozoic (Krause et al., 2022)

dy = zeros(23,1); % Creates empty matrix to hold data generated

% set globals - pulls in information from the front end

global pars
global forcings
global cisotopes
global stepnumber
global workingstate

%% Data loaded in %%%%%%%%%%%%%%%%%%%%% 


%%%% land area
if isfield(mc_params,'land_area_mc')
    f_A_forcing_mc = interp1(forcings.new_f_A(:,1),forcings.new_f_A(:,2), t);
end

if isfield(mc_params,'land_area_mc') == 1
    f_A = f_A_forcing_mc;
else
f_A_forcing = interp1(forcings.new_fA(:,1), forcings.new_fA(:,2), t); 
f_A = f_A_forcing; 
end 
%%%%%%%%%%%

%%%% Change in palaeogeog on temp

if isfield(mc_params,'geog_mc')
    geog_forcing_mc = interp1(forcings.new_geog(:,1),forcings.new_geog(:,2), t);
end

if isfield(mc_params,'geog_mc') == 1
    GEOG = geog_forcing_mc;
else
GEOG_forcing = interp1(forcings.new_GEOG(:,1), forcings.new_GEOG(:,2), t); 
GEOG = GEOG_forcing; 
end
    
%%%%%%%%%%%


%%%% proportion of land area underlain by carbonates
if isfield(mc_params,'carb_area_mc')
    f_L_forcing_mc = interp1(forcings.new_f_L(:,1),forcings.new_f_L(:,2), t);
end

if isfield(mc_params,'carb_area_mc') == 1
    f_L = f_L_forcing_mc;
else
f_L_forcing = interp1(forcings.land_data(:,1), forcings.land_data(:,5), t);
f_L = f_L_forcing; 
end
%%%%%%%%%%%


%%%% runoff
if isfield(mc_params,'runoff_mc')
    f_D_forcing_mc = interp1(forcings.new_f_D(:,1),forcings.new_f_D(:,2), t);
end

if isfield(mc_params,'runoff_mc') == 1
    f_D = f_D_forcing_mc;
else
f_D_forcing = interp1(forcings.land_data(:,1), forcings.land_data(:,4), t);
f_D = f_D_forcing;
end
%%%%%%%%%%%%


%%%% degassing rate due to tectonics
if isfield(mc_params,'degas_mc')
f_G_forcing_mc = interp1(forcings.new_f_G(:,1),forcings.new_f_G(:,2), t);
end

if isfield(mc_params,'degas_mc') == 1
    f_G = f_G_forcing_mc;
else
    f_G_forcing = interp1(forcings.new_degas(:,1), forcings.new_degas(:,4), t);
    f_G = f_G_forcing; 
end

%%% Sensitivity testing - comment in for use and comment out the code above
% f_G = 1;

%%%%%%%%

%%%% This is the fraction of land area experiencing chemical weathering
if isfield(mc_params,'faw_mc')
f_AW_forcing_mc = interp1(forcings.new_f_AW(:,1),forcings.new_f_AW(:,2), t);
end

if isfield(mc_params,'faw_mc') == 1
    f_AW = f_AW_forcing_mc;
else
f_AW_forcing = interp1(forcings.land_data(:,1), forcings.land_data(:,3), t); 
f_AW = f_AW_forcing;
end
%%%%%%%%

%% d34S Isotope data loaded in

% delta_OA_S_forcing = interp1(forcings.d34S(:,1), forcings.d34S(:,2), t);
% delta_OA_S = delta_OA_S_forcing;

%% d34S predicted isotopes

delta_OA_S = y(23) ./ y(1);

%% d13C Isotope data loaded in

% Saltzman d13C average - 10 myr smoothing, values every 0.1 myr

if isfield(mc_params,'c_isotopes_mc')
delta_OA_C_forcing_mc = interp1(cisotopes.new_delta_OA_C(:,1), cisotopes.new_delta_OA_C(:,2), t);
end

if isfield(mc_params,'c_isotopes_mc') == 1
    delta_OA_C = delta_OA_C_forcing_mc;
else
    delta_OA_C_forcing = interp1(cisotopes.OAC_time(:,1), cisotopes.delta_OAC(:,1), t);
    delta_OA_C = delta_OA_C_forcing;
end


%% f_E %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% dependence of weathering rate on soil biological activity due to land plants
LAND = 0.25;
GYM = 0.875;

if isfield(mc_params,'plants_mc') == 1
    MATS = forcings.pre_plant;
else
    MATS = 0.25;
end


if t >= -80
    f_E = 1;
elseif -80 > t && t >= -130
    f_E = (1 - GYM) * ((130 + t) / 50) + GYM;
elseif -130 > t && t >= -350
    f_E = GYM;
elseif -350 > t && t >= -380
    f_E = (GYM - LAND) * ((380 + t) / 30) + LAND;
elseif -380 > t && t >= -470 
    f_E = LAND;
else
    f_E = MATS;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% f_R - mean land elevation (t) / mean land elevation (0)

if isfield(mc_params,'uplift_mc')
f_R_forcing_mc = interp1(forcings.new_f_R(:,1), forcings.new_f_R(:,2), t);
end

if isfield(mc_params,'uplift_mc') == 1
    f_R = f_R_forcing_mc; % 100myr smoothing of Hay data normalised to Miocene
else   
f_R_forcing = interp1(forcings.new_fR(:,1), forcings.new_fR(:,2), t);
f_R = f_R_forcing;
end

%%% Sensitivity testing - comment in for use and comment out the code above
% f_R = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% f_C variable %%%%%%%%%%%%%%%%%
% dependence of degassing rate on relative proportions of carbonates on shallow platforms or deep ocean

old_f_C = 0.75;

if t >= -150
    f_C = old_f_C + (((1 - old_f_C) / 150) * (150 + t)); 
elseif t < -150
    f_C = old_f_C; 
end


%% Atmospheric CO2 %%%%%%%%%%%%%%%%%

atfrac_0 = 0.01614;

atfrac = atfrac_0 * (y(20) / pars.A0);

RCO2 = (y(20) / pars.A0); % ratio of CO2atm at time (t) / time (0) - in PAL


%% Atmospheric O2 %%%%%%%%%%%%%%%%%

O2mr = y(19) / pars.O0; % ratio of O2atm at time (t) / time (0) - in PAL


%% f_CO2 - Effect of CO2 on carb and si weathering 

VAS = ((2 * RCO2) / (1 + RCO2)).^pars.FERT;
NOVAS = RCO2^0.5;

inter_f_CO2 = interp1([0 -350 -380 -1600], [VAS VAS NOVAS NOVAS], t);
f_CO2 = inter_f_CO2;


%% Temp parameter for both carb and si weathering %%%%%%%%%%%%%%%%%
% gamma is response of global mean temp to atmospheric CO2 greenhouse
% effect

if isfield(mc_params,'gamma_mc') == 1
    gamma_monte = forcings.gamma;
else
    gamma_monte = 0;
end

warm = 4 + gamma_monte;
cool = 6 + gamma_monte;
snow = 2 + gamma_monte;


if 0 > t && t >= -40
            gamma = cool;
   
        elseif -260 >= t && t >= -330
            gamma = cool; 
            
        elseif -635 >= t && t >= -650
            gamma = snow;
            
        elseif -680 >= t && t >= -715
            gamma = snow;
            
        else
            gamma = warm; 
    
end
        


if isfield(mc_params,'clim_run_mc') == 1
    snow_RUN = forcings.clim_run;
else
    snow_RUN = 0.045;
end


warm_RUN = 0.025;
cool_RUN = 0.045;

RUN = interp1([-1600 -725 -715 -680 -670 -655 -650 -640 -635 -331 -330 -260 -259 -41 -40 0],[warm_RUN warm_RUN snow_RUN snow_RUN warm_RUN warm_RUN snow_RUN snow_RUN warm_RUN warm_RUN cool_RUN cool_RUN warm_RUN warm_RUN cool_RUN cool_RUN],t) ;


%% Temperature

albedo = (1.4891 - (0.0065979 * y(21)) + (8.567e-6 * y(21)^2)) / pars.albedo_0;

temp = ((gamma * (log(RCO2) / log(2))) - ((pars.Ws * albedo) * (t / -1500)) + GEOG + pars.temp_0); % global average temperature


%% Silicate weathering temp feedback parameter

f_Tsi = exp((pars.ACT_si * (temp - pars.temp_0))) * ((1 + (RUN * (temp - pars.temp_0)))^0.65);


%% Silicate weathering combined temp and CO2 feedback variable

fBsi = f_Tsi * f_CO2;


%% Carbonate weathering temp feedback parameter

f_Tcarb = 1 + (pars.ACT_carb * (temp - pars.temp_0));


%% Carbonate weathering combined temp and CO2 feedback variable

f_BBcarb = f_Tcarb * f_CO2;


%% Make seafloor spreading rate equal tectonic degassing

f_SR = f_G;


%% Carbon weathering

% if t < -541
%     ox_weather = (max(O2mr, 0)).^1; % Comment in, if running sensitivity tests
% else
    ox_weather = (max(O2mr, 0)).^0.5 ;
% end


%%%% increasing crustal carbon
if isfield(mc_params,'crustal_mc')
crustal_forcing_mc = interp1(forcings.new_crustal(:,1),forcings.new_crustal(:,2), t);
end

if isfield(mc_params,'crustal_mc') == 1
    crustal_carbon = crustal_forcing_mc;
else
    crustal_forcing = interp1(forcings.crustal(:,1), forcings.crustal(:,2), t);
    crustal_carbon = crustal_forcing; 
end

relative_crustal_carbon = crustal_carbon / 8500e18; % Normalise to present

%%% Sensitivity testing - comment in for use and comment out the code above
% relative_crustal_carbon = 1;

%%%% Comment out or in the below depending on whether crustal reservoirs
%%%% are increasing (Hayes and Waldbauer, 2006) or calculated dynamically
%%%% (Berner, 2006)

%%% Increasing crustal carbon

F_wg_y =  min ((f_R^0.33 * f_A * pars.k_wg * relative_crustal_carbon * pars.G_y * ox_weather), y(19)); % Weathering of young organic carbon
 
F_wg_a = min ((f_R^0.33 * pars.kwga * relative_crustal_carbon * pars.G_a * ox_weather), y(19)); % Weathering of old organic carbon
 
F_wc_y = f_BBcarb * f_L * f_A * f_D * f_E * pars.k_wc * relative_crustal_carbon * pars.C_y * f_R^0.9; % Weathering of young carbonate

F_wc_a = f_BBcarb * f_L * f_A * f_D * f_E * pars.kwca * relative_crustal_carbon * pars.C_a * f_R^0.9; % Weathering of old carbonate


%%% Dynamically calculated crustal carbon reservoirs

% F_wg_y =  min ((f_R^0.33 * f_A * pars.k_wg * y(7) * ox_weather), y(19)); % Weathering of young organic carbon
%  
% F_wg_a = min ((f_R^0.33 * pars.kwga * y(8) * ox_weather), y(19)); % Weathering of old organic carbon
%  
% F_wc_y = f_BBcarb * f_L * f_A * f_D * f_E * pars.k_wc * y(9) * f_R^0.9; % Weathering of young carbonate
% 
% F_wc_a = f_BBcarb * f_L * f_A * f_D * f_E * pars.kwca * y(10) * f_R^0.9; % Weathering of old carbonate


%% Sulfur weathering

if isfield(mc_params,'gscaling_mc') == 1
    S_pulse = forcings.gscale;
else
    S_pulse = 5;
end

if isfield(mc_params,'pscaling_mc') == 1
    Pyr_pulse = forcings.pscale;
else
    Pyr_pulse = 5;
end

if isfield(mc_params,'evapscaling_mc') == 1
    Evap_pulse = forcings.evapscale;
else
    Evap_pulse = 7;
end


S_scaling = interp1([-1600 -580 -570 -560 -550 0],[1 1 S_pulse S_pulse 1 1],t) ;
PYRB_scaling = interp1([-1600 -580 -570 -560 -550 0],[1 1 Pyr_pulse Pyr_pulse 1 1],t) ;
Evap_scaling = interp1([-1600 -831 -830 -770 -769 0],[1 1 Evap_pulse Evap_pulse 1 1],t);

F_wp_y = (y(22) / pars.F_ws_0) * pars.k_wp * (y(3) / pars.Pyr_0); % Weathering of young pyrite

F_wp_a = f_R^0.33 * pars.kwpa * y(4); % Weathering of old pyrite

F_wgyp_y = (F_wc_y / pars.F_wc_y0) * pars.k_wgyp * (y(5)/pars.Gyp_0) * S_scaling; % Weathering of young gypsum

F_wgyp_a = f_A * f_D * pars.kwgypa * y(6) * S_scaling; % Weathering of old gypsum


%% Degassing

%%% Increasing crustal carbon
Fmg = min( f_SR * pars.kmga * relative_crustal_carbon * pars.G_a, y(19) ); % Degassing of old organic carbon

Fmc = f_SR * f_C * pars.kmca * relative_crustal_carbon * pars.C_a; % Degassing of old carbonate

%%% Dynamically calculated crustal carbon reservoirs
% Fmg = min( f_SR * pars.kmga * y(8), y(19) ); % Degassing of old organic carbon
 
% Fmc = f_SR * f_C * pars.kmca * y(10); % Degassing of old carbonate


Fmp = f_SR * pars.kmpa * y(4); % Degassing of old pyrite
     
Fms = f_SR * pars.kmgypa * y(6); % Degassing of old gypsum



%% Isotope reservoir fluxes

delta_p_y = y(11)/y(3); % young pyrite isotopes
delta_p_a = y(12)/y(4); % ancient pyrite isotopes
delta_gyp_y = y(13)/y(5); % young gypsum isotopes
delta_gyp_a = y(14)/y(6); % ancient gypsum isotopes
% delta_g_y = y(15)/y(7); % young organic carbon isotopes
% delta_g_a = y(16)/y(8); % ancient organic carbon isotopes
% delta_c_y = y(17)/y(9); % young carbonate isotopes
% delta_c_a = y(18)/y(10); % ancient carbonate isotopes


%% Carbon isotope fractionation changes

%%% d13C fractionation equation used in 2008 and 2009, GCBS 2006 uses Hayes
%%% data

%%% J curve fitting parameter
if isfield(mc_params,'J_mc') == 1
    new_J = forcings.J;
else
    new_J = 0.25;
end

%%% Present day average d13c fractionation
if isfield(mc_params,'alpha_0_mc') == 1
    new_alpha_0 = forcings.alpha_0;
else
    new_alpha_0 = 27;
end


%%% Use below if you just want to use the d13c fractionation equation
% alpha_C = new_alpha_0 + (new_J .* (max((y(19) ./ pars.O0), 0) - 1)); % d13C fractionation

%%% Use below if you just want to use the d13c fractionation data
% if isfield(mc_params,'JKT_alpha_mc')
%     alpha_C_forcing_mc = interp1(forcings.new_alpha(:,1),forcings.new_alpha(:,2), t);
%     alpha_C = alpha_C_forcing_mc;
% else
%     alpha_C = 27 + (pars.J .* ((y(19) ./ pars.O0) - 1)); 
% end

%%% Combines both the equation and data d13c fractionation

eq_alpha_C = new_alpha_0 + (new_J .* (max((y(19) ./ pars.O0), 0) - 1));

if isfield(mc_params,'JKT_alpha_mc')
    alpha_C_forcing_mc = interp1(forcings.new_alpha(:,1),forcings.new_alpha(:,2), t);
    dat_alpha_C = alpha_C_forcing_mc;
else
    dat_alpha_C = interp1(forcings.alphaC(:,1), forcings.alphaC(:,4),t); 
end

alpha_C = (eq_alpha_C + dat_alpha_C) / 2;


%% Sulfur isotope fractionation changes

%%% Previous GEOCARBSULF (2006) equation - not used
% alpha_S = 35 .* (max((y(19) / pars.O0).^pars.n, 0)); % d34S fractionation

%%% Use the below if you want to have d34s fractionation based on
%%% Phanerozoic limits
% if isfield(mc_params,'sulf_frac_mc') == 1
%     alpha_S = forcings.sulf_frac;
% else
%     alpha_S = 35;
% end

%%% d34s fractionation based on data
alpha_S_forcing = interp1(forcings.land_data(:,1), forcings.land_data(:,7), t); 
alpha_S = alpha_S_forcing;


%% Carbon burial fluxes
 
F_total_c = F_wc_y + F_wc_a + F_wg_y + F_wg_a + Fmc + Fmg; % All carbon associated inputs into the ocean

f_org = (delta_OA_C - pars.delta_in) / alpha_C; % Fraction of total C as org

F_bg = f_org * F_total_c; % C org burial

%%% Previous method
% F_bg = (1/alpha_C) * (((delta_OA_C - delta_c_y) * F_wc_y) + ((delta_OA_C - delta_c_a) * F_wc_a) + ((delta_OA_C - delta_g_y) * F_wg_y) + ((delta_OA_C - delta_g_a) * F_wg_a) + ((delta_OA_C - delta_c_a) * Fmc) + ((delta_OA_C - delta_g_a) * Fmg));

% Carbonate burial flux
F_bc = y(22) + F_wc_y + F_wc_a;


%% Generate d13c org record

delta_org = delta_OA_C - alpha_C;


%% Sulfur burial fluxes
    
% load Ca_forcing

% ca_time = -1 .* t_Ca;
% Calc = interp1(ca_time, Ca, t); % This is Horita et al's normalised Ca fluid inclusion data

pyr_o2 = O2mr;
if isreal(pyr_o2) == 0
    pyr_o2 = 0 ;
end

foxnew = 2 .* sigmf(-1 .* pyr_o2,[5 -1]);


ocfrac = 1 - atfrac; % Fraction of total C from ocean-atm that is in ocean
DOC_0 = (pars.A0 * ocfrac) / 25; % Present day dissolved C org (DOC)
DOC = (y(20) * ocfrac) / 25; % DOC at time (t)
norm_DOC = DOC / DOC_0; % Normalised DOC

%%% Some runs include dependency on DOC pool - this picks which are/aren't
if isfield(mc_params,'org_dep_mc') == 1
    Org_Dep = forcings.org_dep;
else
    Org_Dep = 1;
end

% Dependent
if Org_Dep <= 0.5
    F_bp = pars.k_bp * (y(1) / pars.OA_S_0) * foxnew * PYRB_scaling * norm_DOC; % (F_bg / pars.F_bg_0) ; % Pyrite burial flux
    F_bgyp = pars.k_bgyp * (y(1) / pars.OA_S_0) * Evap_scaling; % * Calc; % Gypsum burial flux
% Not
else
    F_bp = pars.k_bp * (y(1) / pars.OA_S_0) * foxnew * PYRB_scaling;
    F_bgyp = pars.k_bgyp * (y(1) / pars.OA_S_0) * Evap_scaling; % * Calc; % Gypsum burial flux
end



%% Young to old reservoir fluxes %%%%%%

F_ya_p = y(3) * pars.k_p_ya;
F_ya_gyp = y(5) * pars.k_gyp_ya;
F_ya_g = y(7) * pars.k_g_ya;
F_ya_c = y(9) * pars.k_c_ya;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Silicate Weathering

F_ws = fBsi * ((f_AW * f_A * f_D)^0.65) * f_R^0.33 * f_E * pars.F_ws_0 ; % Silicate weathering

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Mass balance of ocean - atmosphere reservoir

% Ocean-atm sulfur mass balance 

dy(1) = F_wp_y + F_wgyp_y + F_wp_a + F_wgyp_a + Fms + Fmp - F_bp - F_bgyp;


% Ocean-atm carbon mass balance 
dy(2) = F_wg_y + F_wc_y + F_wg_a + F_wc_a + Fmc + Fmg - F_bg - F_bc;


%% Rock reservoirs

dy(3) = F_bp - F_wp_y - F_ya_p; % Young pyrite reservoir

dy(4) = F_ya_p - F_wp_a - Fmp; % Ancient pyrite reservoir

dy(5) = F_bgyp - F_wgyp_y - F_ya_gyp; % Young gypsum reservoir

dy(6) = F_ya_gyp - F_wgyp_a - Fms; % Ancient gypsum reservoir

% dy(7) = F_bg - F_wg_y - F_ya_g; % Young organic carbon reservoir
% 
% dy(8) = F_ya_g - F_wg_a - Fmg; % Ancient organic carbon reservoir
% 
% dy(9) = F_bc - F_wc_y - F_ya_c; % Young carbonate reservoir
% 
% dy(10) = F_ya_c - F_wc_a - Fmc; % Ancient carbonate reservoir


%% Isotope mass balance for rock reservoirs

dy(11) = ((delta_OA_S - alpha_S) * F_bp) - (delta_p_y * F_wp_y) - (delta_p_y * F_ya_p); % Young pyrite isotope

dy(12) = (delta_p_y * F_ya_p) - (delta_p_a * F_wp_a) - (delta_p_a * Fmp); % Old pyrite isotope

dy(13) = (delta_OA_S * F_bgyp) - (delta_gyp_y * F_wgyp_y) - (delta_gyp_y * F_ya_gyp); % Young gypsum isotope

dy(14) = (delta_gyp_y * F_ya_gyp) - (delta_gyp_a * F_wgyp_a) - (delta_gyp_a * Fms); % Old gypsum isotope

% dy(15) = ((delta_OA_C - alpha_C) * F_bg) - (delta_g_y * F_wg_y) - (delta_g_y * F_ya_g); % Young organic C isotope
% 
% dy(16) = (delta_g_y * F_ya_g) - (delta_g_a * F_wg_a) - (delta_g_a * Fmg); % Old organic C isotope
% 
% dy(17) = (delta_OA_C * F_bc) - (delta_c_y * F_wc_y) - (delta_c_y * F_ya_c); % Young carbonate isotope
% 
% dy(18) = (delta_c_y * F_ya_c) - (delta_c_a * F_wc_a) - (delta_c_a * Fmc); % Old carbonate isotope


%% Atmospheric Oxygen

dy(19) = (F_bg + ((15/8) * F_bp)) - (F_wg_y + F_wg_a + Fmg) - ((15 / 8) * (F_wp_y + F_wp_a + Fmp));

%% Atmospheric CO2

dy(20) = F_wg_y + F_wc_y + F_wg_a + F_wc_a + Fmg + Fmc - F_bg - F_bc;


%% Recording of other fluxes for use in equations

dy(21) = temp - y(21);

% dy(21) = temp_gast - y(21);

dy(22) = F_ws - y(22);

dy(23) = ((delta_p_y * F_wp_y) + (delta_p_a * F_wp_a) + (delta_p_a * Fmp) + (delta_gyp_y * F_wgyp_y) + (delta_gyp_a * F_wgyp_a) + (delta_gyp_a * Fms) - ((delta_OA_S - alpha_S) * F_bp) - (delta_OA_S * F_bgyp));


%% Printing of workstates

workingstate.OA_S(stepnumber,1) = y(1);
workingstate.RCO2(stepnumber,1) = RCO2;
workingstate.O2mr(stepnumber,1) = O2mr;
% workingstate.O2_percent(stepnumber,1) = O2_percent;
workingstate.albedo(stepnumber,1) = albedo;
workingstate.temp_degc(stepnumber,1) = temp - 273.15;
workingstate.F_bg(stepnumber,1) = F_bg;
workingstate.F_bp(stepnumber,1) = F_bp;
workingstate.F_bgyp(stepnumber,1) = F_bgyp;

% workingstate.delta_OA_C(stepnumber,1) = delta_OA_C;
workingstate.delta_OA_S(stepnumber,1) = delta_OA_S;
% workingstate.PYRB_scaling(stepnumber,1) = PYRB_scaling;
% workingstate.S_scaling(stepnumber,1) = S_scaling;
workingstate.f_pyr(stepnumber,1) = F_bp / (F_bp + F_bgyp);
% workingstate.DOC_norm(stepnumber,1) = norm_DOC;
workingstate.forg(stepnumber,1) = f_org;
workingstate.alpha_C(stepnumber,1) = alpha_C;
workingstate.delta_org(stepnumber,1) = delta_org;

workingstate.time(stepnumber,1) = t;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

stepnumber = stepnumber + 1 ;


end
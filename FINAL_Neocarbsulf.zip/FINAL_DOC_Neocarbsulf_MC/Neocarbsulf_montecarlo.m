%%%% Monte Carlo run for Neocarbsulf

clear mc_outputs
clear mc_params
clear n
clear options
clear stepnumber
clear pars
clear forcings
clear workingstate
clear state
clear rawoutput

timegrid = -1500:1:0;
timegrid = timegrid';


n = 5000; % Number of model runs

mc_params.init = 1;

mc_params.uplift_mc = 1;
mc_params.degas_mc = 1;
mc_params.gscaling_mc = 1;
mc_params.pscaling_mc = 1;
mc_params.evapscaling_mc = 1;
mc_params.c_isotopes_mc = 1;
mc_params.runoff_mc = 1;
mc_params.faw_mc = 1;
mc_params.carb_area_mc = 1;
mc_params.org_dep_mc = 1;
% mc_params.DOC_res = 1;
% mc_params.sulph_frac_mc = 1;

%% Run Parallel Loop to increase model efficiency 
%(note you can't use global variables within parfor and so monte carlo forcings should be created within Neocarbsulf_frontend_MC if using this approach)
parfor s = 1:n
    disp(s)
    run(s).output = Neocarbsulf_frontend_MC(s,mc_params); % Run Neocarbsulf
end

mc_params_fieldnames = fieldnames(mc_params);
fprintf('------------------------------- \n');
fprintf('Parameters used in Monte Carlo: \n');
disp(mc_params_fieldnames) % Print parameters used in Monte Carlo analysis
clear mc_params_fieldnames
fprintf('------------------------------- \n');

save('mc_runs.mat','run','-v7.3');


%% Process Outputs

state_fields = fieldnames(run(1).output.state);
% Make sure outputs have valid names, ready for adding to a single structure
 
for modelrun = n:-1:1
    for i=1:length(state_fields)
        varName(i) = matlab.lang.makeValidName(string(state_fields(i)));
        grid_outputs.(varName(i))(:,modelrun) = run(modelrun).output.state.(string(state_fields(i)));
        grid_outputs.(varName(i))(imag(grid_outputs.(varName(i))) ~= 0) = NaN;
        clear varName
    end
end

clear run % Remove all state outputs once gridded to save space
 
grid_fields = fieldnames(grid_outputs);
% Add all gridded outputs to a single structure for cleanliness
% fprintf('------------------------------- \n')
% fprintf('Creating Output Data Structure \n')

for ni=1:length(grid_fields)
    temps = string(grid_fields(ni));
    tempname = matlab.lang.makeValidName(strsplit(temps,'_gridded'));
    varName(ni) = tempname(1);
    mc_outputs.(varName(ni)) = grid_outputs.(string(grid_fields(ni)));
    % Calculate Max and Min Value at each Time Step for each Variable
    for i=1:length(timegrid)
        mc_outputs.max.(varName(ni))(i) = max(grid_outputs.(string(grid_fields(ni)))(i,:));
        mc_outputs.min.(varName(ni))(i) = min(grid_outputs.(string(grid_fields(ni)))(i,:));
    end
    mc_outputs.max.(varName(ni)) = mc_outputs.max.(varName(ni))'; % Flip from row to column for plotting
    mc_outputs.min.(varName(ni)) = mc_outputs.min.(varName(ni))'; % Flip from row to column for plotting
    clear varName temps tempname
end



fprintf('------------------------------- \n')

clear grid_outputs % Clear gridded outputs to clean up workspace

% Calculate statistics
fields = fieldnames(mc_outputs);
fields(ismember(fields,'max')) = []; % Remove from fields cell array to avoid error in subsequent loop (i.e. dont want to calculate mean of the max data values)
fields(ismember(fields,'min')) = []; % Remove from fields cell array to avoid error in subsequent loop

for ni=1:length(fields)
    varname = string(fields(ni));
%     mc_outputs.CI95.(varname) = ones(length(mc_outputs.(varname)),2);
%     disp(ni)
%     for i = 1:length(mc_outputs.(varname))
    for i = 1:length(timegrid)
        x = mc_outputs.(varname)(i,:);
%         SEM = nanstd(x) ./ sqrt(length(x));               % Standard Error
%         ts = tinv([0.025  0.975],length(x)-1);      % T-Score
%         CI = nanmean(x) + ts * SEM;                      % Confidence Intervals
%         mc_outputs.CI95.(varname)(i,:) = CI ;
       
        meanx = nanmean(x);
        medianx = nanmedian(x);
        stdx = nanstd(x);
        mc_outputs.medians.(varname)(i,:) = medianx;
        mc_outputs.means.(varname)(i,:) = meanx;
        mc_outputs.stds.(varname)(i,:) = stdx;
        mc_outputs.min1.(varname)(i,:) = meanx - stdx;
        mc_outputs.plus1.(varname)(i,:) = meanx + stdx;
        
        mc_outputs.CImin.(varname)(i,:) = mean(x) - (1.96 * (std(x) / sqrt(n)));
        mc_outputs.CImax.(varname)(i,:) = mean(x) + (1.96 * (std(x) / sqrt(n)));
        clear x SEM ts CI meanx stdx medianx
    end
end

%%% Convert CO2 to ppm and OA Sulphur to mM
co2ppm = mc_outputs.means.RCO2 .* 280;
co2min1 = mc_outputs.min1.RCO2 .* 280;
co2plus1 = mc_outputs.plus1.RCO2 .* 280;
co2CImin = mc_outputs.CImin.RCO2 .* 280;
co2CImax = mc_outputs.CImax.RCO2 .* 280;

sulphmM = mc_outputs.means.OA_S ./ 0.001 ./ 1.338e21;
sulphmin1 = mc_outputs.min1.OA_S ./ 0.001 ./ 1.338e21;
sulphplus1 = mc_outputs.plus1.OA_S ./ 0.001 ./ 1.338e21;
sulphCImin = mc_outputs.CImin.OA_S ./ 0.001 ./ 1.338e21;
sulphCImax = mc_outputs.CImax.OA_S ./ 0.001 ./ 1.338e21;

%%% Plot outputs

figure
hold on
plot(timegrid,mc_outputs.means.O2mr,'k')
% plot(timegrid,mc_outputs.CImin.O2mr,'b')
% plot(timegrid,mc_outputs.CImax.O2mr,'b')
plot(timegrid,mc_outputs.min1.O2mr,'c')
plot(timegrid,mc_outputs.plus1.O2mr,'c')
xlabel('Time (Ma)')
ylabel('pO_2 (PAL)')

figure
subplot(3,2,1)
hold on
plot(timegrid,co2ppm,'k')
% plot(timegrid,co2CImin,'b')
% plot(timegrid,co2CImax,'b')
plot(timegrid,co2min1,'c')
plot(timegrid,co2plus1,'c')
ylabel('CO_2 (ppm)')

subplot(3,2,2)
hold on
plot(timegrid,mc_outputs.means.temp_degc,'k')
% plot(timegrid,mc_outputs.CImin.temp_degc,'b')
% plot(timegrid,mc_outputs.CImax.temp_degc,'b')
plot(timegrid,mc_outputs.min1.temp_degc,'c')
plot(timegrid,mc_outputs.plus1.temp_degc,'c')
ylabel('Temp (deg C)')

subplot(3,2,3)
hold on
plot(timegrid,mc_outputs.means.forg,'k')
% plot(timegrid,mc_outputs.CImin.forg,'b')
% plot(timegrid,mc_outputs.CImax.forg,'b')
plot(timegrid,mc_outputs.min1.forg,'c')
plot(timegrid,mc_outputs.plus1.forg,'c')
ylabel('f_o_r_g')

subplot(3,2,4)
hold on
plot(timegrid,mc_outputs.means.f_pyr,'k')
% plot(timegrid,mc_outputs.CImin.f_pyr,'b')
% plot(timegrid,mc_outputs.CImax.f_pyr,'b')
plot(timegrid,mc_outputs.min1.f_pyr,'c')
plot(timegrid,mc_outputs.plus1.f_pyr,'c')
ylabel('f_p_y_r')

subplot(3,2,5)
hold on
plot(timegrid,sulphmM,'k')
% plot(timegrid,sulphCImin,'b')
% plot(timegrid,sulphCImax,'b')
plot(timegrid,sulphmin1,'c')
plot(timegrid,sulphplus1,'c')
xlabel('Time (Ma)')
ylabel('O-A Sulphate (mM)')

subplot(3,2,6)
hold on
plot(timegrid,mc_outputs.means.delta_OA_S,'k')
% plot(timegrid,mc_outputs.CImin.delta_OA_S,'b')
% plot(timegrid,mc_outputs.CImax.delta_OA_S,'b')
plot(timegrid,mc_outputs.min1.delta_OA_S,'c')
plot(timegrid,mc_outputs.plus1.delta_OA_S,'c')
xlabel('Time (Ma)')
ylabel('d^3^4S (per mille)')

 
% %%% Plot all O2 outputs at once
figure
hold on
for j = 1:n
plot(timegrid,mc_outputs.O2mr(:,j))
end
xlabel('Time (Ma)')
ylabel('pO_2 (PAL)')
